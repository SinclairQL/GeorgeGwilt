#ifndef _WDEF_H
#define _WDEF_H


/* 8th June 2004
 *
 * Declaration of "getsze" added - 4th February 2000
 * Declaration of "getptr" added - 5th February 2000
 * Alteration to WAPPL etc - 19th May 2001
 * Addition of macros (MAX etc), externs and declarations "slitem" &
 *	"do_sleep1/3" -  8th February 2004
 * Correction of extern for size sprite  (sz -> sze) - 21st April 2004
 * Addition of wm__smnu - 8th June 2004
 */

#define MAX(A,B) ((A) > (B) ? (A) : (B))
#define MIN(A,B) ((A) < (B) ? (A) : (B))
#define EVEN(A) ((A) & 1  ? (A)+1 : (A))
#define wm__smnu _wm__smnu


typedef struct WM_wdefa WM_wdefa_t;
typedef struct WM_wdefb WM_wdefb_t;
typedef struct WM_wdefc WM_wdefc_t;
typedef struct WM_wdef1 WM_wdef1_t;
typedef struct WM_wdef2 WM_wdef2_t;
typedef struct WM_wdef3 WM_wdef3_t;
typedef struct WM_wdef4 WM_wdef4_t;
typedef struct WM_mattr WM_mattr_t;
typedef struct WM_apinfo WM_apinfo_t;
typedef struct WM_aobl WM_aobl_t;
typedef struct WM_alitm WM_alitm_t;
typedef struct WM_dappw WM_dappw_t;
typedef struct WM_dps WM_dps_t;
typedef struct WM_dmenw WM_dmenw_t;
typedef struct WM_drowl WM_drowl_t;
typedef struct WM_dmobj WM_dmobj_t;

/* "WDEF(N,A)" followed by appropriate numbers initialises a window definition
 * called "A" with N repeated sections. (N must be one of 1, 2, 3 or 4.)
 */

#define WDEF(N,A) static int A ## _sizes[(N)];\
static WM_wdef ## N ## _t A =

struct WM_mattr
{
short curw;
short curc;
short uback;
short uink;
short ublob;	/*  a word pointer	*/
short upatt;	/*	"         */
short aback;
short aink;
short ablob;	/*  a word pointer	*/
short apatt;	/*	"         */
short sback;
short sink;
short sblob;	/*  a word pointer	*/
short spatt;	/*	"         */
};
struct WM_wdefa
{
short xsize;
short ysize;
short xorg;
short yorg;
WM_wattr_t wattr;
short sprt;
WM_mattr_t lattr;
short help;
};

struct WM_wdefb /* This is the repeated section */
{
short xsize;
short ysize;
short pinfo;	/*  a word pointer	*/
short plitem;	/*	"         */
short pappl;	/*	"         */
};

struct WM_wdefc	/* This is the end section */
{
short end;	/* Marks the end for QPTR routines	*/
short ptr1;	/* Allows access to a C constant etc
		 * via HIT, ACTION etc routines	*/
long addr;
};


struct WM_wdef1
{
WM_wdefa_t wdefa;
WM_wdefb_t wdefb[1];
WM_wdefc_t wdefc;
};
struct WM_wdef2
{
WM_wdefa_t wdefa;
WM_wdefb_t wdefb[2];
WM_wdefc_t wdefc;
};
struct WM_wdef3
{
WM_wdefa_t wdefa;
WM_wdefb_t wdefb[3];
WM_wdefc_t wdefc;
};
struct WM_wdef4
{
WM_wdefa_t wdefa;
WM_wdefb_t wdefb[4];
WM_wdefc_t wdefc;
};

/* 1. WMENZ heads the initialisation of an application window, "A",
 *    with a menu but with no control sections.
 *
 * 2. WMEN(N,A) heads the initialisation of a menu application window, "A",
 *    with N (1 or 2) control sections called app2[]. The first part is
 *    called app1.
 *
 * 3. W_OBL(N,A) initialises list "A" of N information objects obl[].
 *
 * 4. W_INFW(N,A) initialises list "A" of N information windows "info[]".
 *
 * 5. W_LITM(N,A) initialises list "A" of N loose items "litm[]".
 */

#define WMENZ(A) static struct {WM_dappw_t app1;WM_dmenw_t men;} A =
#define WMEN(N,A) static struct {WM_dappw_t app1;WM_dps_t app2[(N)];\
WM_dmenw_t men;} A =
#define W_OBL(N,A) static struct {WM_aobl_t obl[(N)];short end;} A =
#define W_INFW(N,A) static struct {WM_apinfo_t info[(N)]; short end;} A =
#define W_LITM(N,A) static struct {WM_alitm_t litm[(N)]; short end;} A =

struct WM_apinfo
{
short xsize;
short ysize;
short xorg;
short yorg;
WM_wattr_t wattr;
short pobl;	/*  a word pointer	*/
};

struct WM_aobl
{
short xsize;
short ysize;
short xorg;
short yorg;
char type;
char spar;
union
{ struct
{ short ink;
  char cwid;
  char chgt;
} t;
short comb;	/*  a word pointer	*/
} attr;
short pobj;	/*  a word pointer	*/
};

struct WM_alitm
{
short xsize;
short ysize;
short xorg;
short yorg;
char xjst;
char yjst;
char type;
unsigned char skey;
short pobj;	/*  a word pointer	*/
short item;
short pact;	/*  a word pointer	*/
};

/* The list of application windows is a list of word pointers.
 * It is not sensible to create a general structure for them.
 *
 * The application windows themselves may need 0, 1 or 2 sets of
 * pan/scroll information. The structures for pan/scroll are thus
 * separated from the first fixed part of the application window
 * information.
 */

struct WM_dappw
{
short xsize;
short ysize;
short xorg;
short yorg;
short flag;
short borw;
short borc;
short papr;
short pspr;	/*  a word pointer	*/
short setr;	/*	"         */
short draw;	/*	"         */
short hit;	/*	"         */
short cntrl;	/*	"         */
short nxsc;
short nysc;
char skey;
char spr1;	/* Put 1 here to signal 'menu' to follow */
};

struct WM_dps
{
short part;	/*  a word pointer	*/
short insz;
short insp;
short iciw;
short icic;
short back;
short ink;
short blob;	/*  a word pointer	*/
short patt;	/*	"         */
short psac;	/* arrow color	*/
short psbc;	/* background color */
short pssc;	/* bar section color*/
};

/* The menu information is initially the same as for the application
 * subwindow, including the optional pan/scroll items. To allow for this
 * the menu structure is the rump after any pan/sroll structures.
 *
 * It is up to the programmer to make up the total.
 *
 * Note that, as the QPTR software requires, but does not detect, the presence
 * of menu information, a positive signal should be given that a menu exists.
 * This is done by filling 'spr1' at the end of WM_dappw with the number 1.
 * A zero signals 'no menu'.
 *
 * This signal is used by the function "getsze", introduced to set the sizes
 * of different window layouts. This function also sets the word links required
 * in the window definition. While doing this it needs to know if menu 
 * information is present. The program clears the item "spr1".
 *
 * In the source code each pointer should be prefixed with "%%<" and suffixed
 * with ">". Thus the pointer
 *
 *		&plitm
 *
 * should be written
 *
 *		%%<&plitm>
 *
 * Sometimes pointers refer to external structures not needing their addresses
 * adjusted. To signal this an extra "<" should be inserted in the prefix.
 * An example of this is a sprite. Thus the pointer to "amove" sprite would
 * appear as
 *
 *		%%<<&mes_move>
 */


struct WM_dmenw
{
short mstt;	/*  a word pointer	*/
short curw;
short curc;
short uback;
short uink;
short ublob;	/*  a word pointer	*/
short upatt;	/*	"         */
short aback;
short aink;
short ablob;	/*  a word pointer	*/
short apatt;	/*	"         */
short sback;
short sink;
short sblob;	/*  a word pointer	*/
short spatt;	/*	"         */
short ncol;
short nrow;
short xoff;
short yoff;
short xspc;	/*  a word pointer	*/
short yspc;	/*	"         */
short xind;	/*	"         */
short yind;	/*	"         */
short rowl;	/*	"         */
};

struct WM_drowl
{
short rows;	/*  a word pointer	*/
short rowe;	/*	"         */
};

struct WM_dmobj
{
char xjst;
char yjst;
char type;
char skey;
short pobj;	/*  a word pointer	*/
short item;
short pact;	/*  a word pointer	*/
};

extern WM_sprite_t cpt_hand_spr;
extern WM_sprite_t cpt_zzz_spr;
extern WM_sprite_t cpt_dia_spr;
extern WM_sprite_t cpt_circ_spr;
extern WM_sprite_t cpt_nul_spr;
extern WM_sprite_t cpt_wake_spr;
extern WM_sprite_t cpt_left_spr;
extern WM_sprite_t cpt_right_spr;
extern WM_sprite_t cpt_up_spr;
extern WM_sprite_t cpt_down_spr;
extern WM_sprite_t cpt_mve_spr;
extern WM_sprite_t cpt_sze_spr;
extern WM_sprite_t cpt_curt_spr;
extern WM_sprite_t cpt_lr_pat;
extern WM_sprite_t cpt_re_pat;
extern WM_sprite_t cpt_gr_pat;
extern WM_sprite_t cpt_dg_pat;
extern WM_sprite_t cpt_dr_pat;
extern WM_sprite_t cpt_lg_pat;
extern WM_sprite_t cpt_gy_pat;
extern WM_sprite_t cpt_wh_pat;
extern WM_sprite_t cpt_mu_pat;
extern WM_sprite_t cpt_bl_pat;



#ifdef __STDC__
#define _P_(params) params
#else
#define _P_(params)
#endif

int getsze	_P_ ((void *,void *,void *,void *,void *));
int getptr	_P_ ((WM_wwork_t *));
int slitem	_P_ ((WM_wwork_t *, short , short ));
void do_sleep1	_P_ ((chanid_t chid,WM_wwork_t *,short,void *,void *,int *));
void do_sleep3	_P_ ((chanid_t chid,WM_wwork_t *,short,void *,void *,int *));
void Chk_In	_P_ ((WM_litm_t *, WM_wstat_t *, short, short *, short *,\
short *, short *));
short is_in	_P_ ((short, short, short, short, short, short));
int do_fls	_P_ ((void *, void *));
void wm__smnu	_P_((void));

#undef _P_

#endif /* _WDEF_H */
