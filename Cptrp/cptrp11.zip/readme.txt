                                 CPTR

                       C68 and POINTER ENVIRONMENT

                                  by
                             George Gwilt


                               CONTENTS

INTRODUCTION
  Brief overview

WDEF_H
  A new header file

RELATIVE POINTERS
  A new way of solving the problem

WRAPPERS
  Some additional information

MAKEFILE & SETW
  Making life easier

NOTES ON FILES
  Necessary files and examples

APPENDIX A
  Specification of routines

APPENDIX B
  Sprites and Patterns


                             INTRODUCTION

The four files comprising CPTR provide a way of using C68 to develop programs
for the Pointer Environment (PE) designed to make it easy to re-size or
buttonise a window as well as making the programs "future-proof".

CPTR contains three additional elements to the system described by Tony Tebby in
WMANTUT_DOC, allowing C68 programmers to access PE via the window definition.
The elements are:

a.   The header file WDEF_H defining additional structures needed for the window
definition.

b.   The library libcptr which contains functions and sprites.

c.   The pre-processor program "spr".

d.   The fourth file is the program SETW making it easy to design windows. This
is obtainable from the SQLUG site in the set of files with the name "setw..."



                               WDEF_H

C68's library "libqptr" contains the function "wm_setup" one of whose parameters
is "WM_wdef_t *" although there is no definition of that typedef in QPTR_H. This
is remedied by the header file WDEF_H in which structures for a window
definition are declared.

Actually there are four typedefs defined for window definitions. This is because
a window definition can have any number from 1 upwards of "repeated sections",
each defining a smaller size than the last. To accommodate this, WDEF_H defines
WM_wdefx_t, where x can be 1, 2, 3 or 4. In practice I would expect that only
two of these, WM_wdef1_t and WM_wdef2_t, would be used.

It was said above that the use of CPTR would make programs "future-proof". The
reason for this is that in two places in the orthodox PE system as defined in
the QPTR Manual there is a pointer to the window definition. One of these is in
the working definition. In Tony Tebby's system this has been replaced by a
pointer to a new structure, unnecessary in the official PE system, called
WM_wscale_t. The other pointer is in the status block WM_wstat_t. The danger in
this arises when a future change in PE makes use of these pointers and as a
result renders some existing programs unusable. Use of CPTR prevents this.

The full definitions of all the structures defined are, of course, given in
WDEF_H along with some explanatory notes. A brief indication is give here.

Most structures in QPTR_H containing long word pointers are mirrored in WDEF_H
with word pointers. These are:

  QPTR_H      WDEF_H

  WM_infw     WM_apinfo      information window
  WM_info     WM_aobl        information object list
  WM_litm     WM_alitm       loose item list
  WM_rowl     WM_drowl       row list for application window
  WM_mobj     WM_dmobj       menu object list

The form of main and application windows differs radically from window
definition to working definition. The main window structure in WDEF_H is split
into three parts:

  WM_wdefa       the fixed part
  WM_wdefb       the repeated section
  WM_wdefc       contains the end marker (-1) and 3 communication bytes

Similarly the structure for the application window consists of three parts:

  WM_dappw       the fixed part
  WM_dps         there may be 0, 1 or 2 for pannable/scrollable windows
  WM_dmenw       needed for a menu application window

In addition to these structures five initialising macros are defined.

  WDEF(N,A)         for a main window A with N repeated sections
  WMENZ(A)          for application window A with a menu but no control
                    sections
  WMEN(N,A)         as for WMENZ(A) but with N control sections ( 1 or 2 )
  W_OBL(N,A)        for a list A of N information objects
  W_LITM(N,A)       for a list A of N loose items


                           RELATIVE POINTERS

Inside the window definition are many relative pointers, usually of word
length, so it is not possible to set their values directly while initialising
the structure in which they appear. The solution adopted is to enclose the
pointer in

           %%< . . . >

and to end up with the line

           %%<>;

Thus, if we want to point from the main definition to a list of information
windows called "winf", we would put

        %%<&winf>

at the appropriate place in the structure.

If the target is an external item already containing the correct relative
pointers, such as the sprite mes_move, the pointer must have two "<"s as in

        %%<<&mes_move>

The C program must then be saved with a name with the tail "_z" appended.

The program "spr" invoked by

        ex spr;"filename[_z]"   (NOTE: the "_z" is optional)

will produce "filename_c" ready for compilation by C68.

The program "spr" sets up an array, prtab[], of all the marked pointers
replacing each one by a number representing its position in the array. The
routine "getsze" must be used when the program runs to translate these numbers
into the required relative pointers in the entire window definition. While doing
this getsze also calculates and stores the size to be allocated for working
definitions.

Thus

        getsze(&wd,prtab,&ws,wd_sizes,&num);

will process the window "wd" defined by WDEF(n,wd).

  &wd         is the address of the window definition
  prtab       is the name given by "spr" to the array of pointers
  &ws         is the address of the window status area
  wd_sizes[]  is the array set up by WDEF to contain the sizes for each repeat
  &num        is the address of an integer initially containing the total
              number of complete window definitions

The size of the rth repeat will be set by getsze in

        wd_sizes[r-1]

Finally getsze sets the six bytes after the end of the window definition proper
for communication between PE and C68. (See the next section, WRAPPERS.)


                                  WRAPPERS

The purpose of "wrappers" is described on page 2 of WMANTUT_DOC. On page 10 of
LIBQPTR_DOC they are again mentioned. It is not immediately clear from this how
they are to be used. This section is intended to cast a glimmer of light on the
subject.

All the wrappers are used as part of the structure WM_action. For example we
might declare:

        struct WM_action ahit = {JSR, wm_hitaw, dhit};

We would then set a pointer to ahit at the item "hit" in an application window.
(See WM_dappw in WDEF_H.) When a hit occurs, the PE software passes control to
the wrapper, wm_hitaw, which sets up parameters for the C routine dhit. When
that routine is finished wm_hitaw passes control back to PE. The same procedure
occurs whichever wrapper routine is used except that each wrapper sets
different parameters. Hence, in order that a C programmer can write any of
these internal routines (such as dhit), a knowledge of exactly what parameters
are set by each wrapper is essential. This follows.

It is also useful to know what happens to any return from the user's routine.

1. wm_actli      (entered from a loose item action)

 Parameters

  WM_wwork_t *      -> working definition
  WM_litm_t *       -> the current item
  WM_wstat_t *      -> window status area
  short, short      pointer position (absolute)
  short             uppercased keystroke
  short             event number of keystroke

 Return

  When the user routine ends, the results will determine whether wm_rptr will
continue to read the pointer or whether it will return. It will return if there
was an event keystroke causing the action routine to be entered. It will also
return if the user routine returns a non zero number. If this number is
negative, it is returned by wm_rptr and so can be detected by the user. If, on
the other hand, the number is positive, wm_rptr returns the number zero to the
user, who thus has no direct knowledge of the number returned by the user
routine.

But, for example, if the user routine is entered from a "hit" on the loose item,
and the user routine returns zero when it completes, wm_rptr continues to read
the pointer.



2. wm_actme      (entered from a menu item)

 Parameters

  WM_wwork_t *      -> working definition
  WM_appw_t *       -> the particular application window
  pointer *         -> menu status block
  short, short      column/row for menu item
  short             item number
  short             event number of keystroke

 Return

  A positive non-zero return from the user routine is used to set the window
event and force an exit from wm_rptr, although wm_rptr itself returns zero to
the user.

3. wm_actme      (entered from an application window setup routine)

 Parameters

  WM_wwork_t *      -> working definition (updated pointer)
  WM_wdef_t *       -> window definition (updated pointer)
  WM_wstat_t *      -> window status area
  short             undefined
  short             x-scaling
  short             y-scaling

 Return

  A positive return from the user routine is ignored.

NOTE 1: Since Tony Tebby went straight to the working definition there was no
need for him to produce a wrapper for the window setup routine since its pointer
occurs only in the window definition. Never mind - the wrapper, wm_actme, sets
sufficient parameters.

NOTE 2: The function wm_setup, which produces a working definition from the
window definition, calls, as a subroutine, the application setup routine for
each application window. The standard routine provided by the PE for this
purpose is wm_smenu. Unfortunately the wrapper wm_actme cannot be used
successfully to call wm_smenu. The reasons are that wm_smenu needs as parameters
pointers to pointers for the working definition and the window definition, not
pointers to these as set by the wrapper; and that wm_setup needs the contents of
registers A3 and A4 to be updated after each call to the application window
setup routine whereas wm_smenu preserves the initial values of these registers.

A direct call to the PE routine WM.SMENU can be set by using wm__smnu instead of
the wrapper wm_actme. Versions of libcptr_a in cptrp10_zip or later contain
wm__smnu, which is analogous to the standard wm__mhit which can be used instead
of the wrapper wm_hitaw.


4. wm_drwaw      (entered from an application window draw routine)

 Parameters

  WM_wwork_t *      -> working definition
  WM_appw_t *       -> this application window
  short             x-origin of main window
  short             y-origin of main window
  chanid_t          channel ID of main window

 Return

 Only error returns are made. There is no provision for user set return.


5. wm_hitaw      (entered from an application window hit routine)

 Parameters

  WM_wwork_t *      -> working definition
  WM_appw_t *       -> this application window
  WM_wstat_t *      -> window status area
  short, short      pointer position in application window
  short             uppercased keystroke
  short             event number of keystroke

 Return

 If the user routine returns an error code this is passed on. However, a short,
or zero, number may be returned by the user routine. This acts as timeout for
further reading of the pointer. This enables continuous monitoring of the
keypress.


6. wm_ctlaw      (entered from an application window control routine)

 Parameters

  WM_wwork_t *      -> working definition
  WM_appw_t *       -> this application window
  WM_wstat_t *      -> window status area
  short             position of hit on bar ELSE -1 if hit on arrow
  short             length of bar          ELSE -1 if hit on arrow
  short             item number        ** See NOTE below **
  short             pan/scroll event

 Return

  The user routine can return an error code in the usual way. If it returns a
positive non-zero number this is taken as a window event to be set. wm_rptr will
then return.


NOTE

For some reason the possible values of the item number and their meanings are
not given in the QPTR Manual. In case others want to know these I give them
here.

The ms byte is k which can have the values below:

Value of k

  Space/Hit        Enter/Do            Where
      $70               $74            Top arrows
      $71               $75            Bottom arrows
      $72               $76            Left arrows
      $73               $77            Right arrows
      $78               $7C            Scroll bar
      $7A               $7E            Pan bar

The ls byte is the number of the split in the scroll/pan bar (0, 1 etc).



Communication

It will be appreciated that any routine written to be called by a wrapper
cannot have any but the prescribed parameters. Communication with the outside
world seems lost! This problem is overcome by allowing a programmer to specify
one pointer to which he can have access inside the wrapper. This pointer must
be specified during the initialisation of the main window immediately after the
-1 signalling the end of the repeated sections. There should follow a zero.

For example, if the programmer wanted to access a structure called "ast", the
end of the main window initialisation would be:

           .  .  .  -1,%%<&ast>,0};

Inside the routine called by the wrapper the programmer can access ast by, eg

           addr = (struct apple *) getptr(wwk);

where the structure of ast is called apple, and wwk is the first parameter of
the internal routine, which in the case of every wrapper is the pointer to the
working definition.


                           MAKEFILE & SETW


MAKEFILE

If a program is being produced by "make", the pre-processing of _z files to _c
files by the program "spr" becomes particularly easy. The lines

  _z_c
     spr name

at the end of the makefile turn name_z into name_c.

Indeed, since spr simply copies any files not having any relative pointers, no
harm is done by calling all source files _z and applying spr to them.


SETW


General

Production of the definition of windows can be made easier by the use of the
program SETW which automatically sets up the instructions initializing the
windows and puts these in the _z file. In the course of operation SETW shows the
resultant windows and also produces a _WDA file suitable for use in TurboPTR and
a _BIN or _REL file suitable for Assembler programs.

SETW operates by first asking questions about the window makeup and then by
displaying the window on the screen so that it can be resized by use of the
arrow keys. All information windows, application windows and their objects as
well as loose items are similarly displayed for placing and sizing by the user.

The program SETW was written in S*BASIC and compiled by Turbo, but no extensions
need be loaded before their use since those necessary are included in each
program.

More detailed information about how SETW operates is given in its manual
"setw_text".


How to Use SETW with C68

All the details about the windows to be used in a program are produced by SETW.
It simply remains to fine tune these to the programmer's needs and, of course,
to write the functions which will cause the menu items to do what the programmer
wants.

This section gives information about this process.

There are five main sections in the _z file produced by SETW:

a) The "includes" up to "_prog_name"
b) Declarations of functions
c) The window definition ending with "%%<>"
d) The start of the program
e) The standard function ddraw

The largest section, the window definition, will generally need no alteration.
Alterations to the other sections will be needed.


Alterations to a)

The "includes" may need to be augmented, depending on the program. For instance,
Ex1 uses string functions, so <string.h> has to be added to the includes.

Also it will generally be a good idea to alter the filename from "Name".


Alterations to b)

This section contains declarations of all the functions which need to be written
by the programmer. There may be up to two groups of these functions.

The first group is for menu items in application windows. These functions have
the general name

         apitx_y

where x is a number depending on an application window's object list. Thus
apit2_3 refers to the "hit" routine for object nmuber 3 in the object list
numbered 2.

The second group is for the loose menu items. These have the general name

         alitx_y

where x relates to a repeated section in a main window and y is the item number
of loose item in that repeated section.

Hence alit1_0 would be the function for the first loose item in the second
repeated section.


As explained in WRAPPERS, each of the functions will have a prescribed set of
parameters set for them. Since it is not necessary to use all, or indeed any, of
the parameters a programmer can alter the declarations of any of these functions
to suit. In Ex1, for example, apit2_0 is declared with no parameters.


Alterations to d)

The alterations to the penultimate section consist of the user's program, which
can be as simple as just reading the pointer by, say,

         while (!WM_rptr( (wwork_t *)wwa))
         {
         }

Alterations to e)

The user will need to add the code for the functions declared in b) above.



New Version of WMAN

The new version of WMAN allows GD2 colours to be set in a window definition. It
also has an extended definition of sprites and includes several new Trap #3
routines and new vectored routines.

The extended sprite definition allows system sprites, which now number 38, to be
defined in one word.

To take account of these differences between old and new versions of WMAN, SETW
produces slightly differing _z files depending on the version.

The differences affect the "includes" and sprites as follows.


Includes

To allow for new definitions of sprites and the new routines,

         #include"wman.h"

is added for the new version of WMAN.

(NOTE. An updated version of qptr_h is available on the SQLUG website. This
contains header information for the new WMAN so that wman_h does not need to be
called.)


Sprites

For the new version of WMAN an array SYS_SPR[] is set up to cover the new system
sprites. If, for example, a move sprite is used as a loose item it will be
referred to as "SYS_SPR+6" in the new version whereas in the old version it will
be set as "wm_sprite_move".






                    NECESSARY FILES and EXAMPLES

1. Necessary Files

The files needed for CPTR are the three system files:

  spr             the pre-processing program mentioned above
  wdef_h       *  the header file
  libcptr_a       the library containing functions, sprites & patterns (See
                  Appendix A)

and the manual:

  readme_txt      this file

* The file marked with an asterisk contains more information than is given here.


2. Examples

In addition there are four examples the first, Ex0, showing how the common
procedures Move, Resize, Sleep and Exit can be programmed using CPTR. The
second, Ex1, shows how to set a menu with scrolling in an application window.
The third, Ex2, introduces "dragging" and shows the use of iop_rptr rather than
wm_rptr. The fourth, Ex3, shows a way of producing explanatory windows.

The compiled programs are not intended for actual use, but rather as indications
of the ways in which CPTR and C68 can feature in writing PE programs. Full
information is given inside each _z source code.

The source code for each program is in the files Ex0_z, Ex1_z etc.


3. Files on the SQLUG website

All the files relating to CPTR are available on the SQLUG website

         www.jms1.supanet.com

They are to be found in cptrp09_zip and cptrs09_zip. The number "09" relates to
the version and will be changed as required. The letters "p" and "s" which
appear immediately before the version number signify "program" and "source".


                              APPENDIX A
                         Routines in LIBCPTR


LIBCPTR contains a set of routines and a set of sprites and patterns. The
routines are first described then specified here. The sprites and patterns are
dealt with in APPENDIX B.


Description of Routines

a. Essential routine - getsze

As described in the section "Relative Pointers" above, getsze MUST be used in
every CPTR program to complete the window definition and calculate the size of
each working definition.


b. Communication - getptr

As indicated in the section on Wrappers, communicatioon can be made via an
address at the end of a window definition. getptr is useful for this.


c. QMenu - do_fls

The facilities in the extension Thing, QMenu, require a subroutine inside the
extension Thing to be called. The routine do_fls does this.


d. Buttonising - do_sleep3

The routine do_sleep3 makes it easy to send a program to a button.


e. Using iop_rptr - Chk_In and is_in

Programmers wanting to use iop_rptr instead of wm_rptr to read the pointer
should find these functions useful. They provide a means of putting borders
round loose items under the pointer and also keeping track of the pointer's
position.


f. Setting loose items - slitem

The status of loose items can be set by slitem.


g. Standard setup for application windows - wm__smnu

Application windows with a menu can be set up from the window definition using
wm__smnu.


Specification of Routines


These routines are included in the library LIBCPTR. The routines are all
declared in the header file WDEF_H and so can be used directly in a program
without further declaration.

----------------------------------------------------------------------------
void Chk_In (WM_litm_t *lad, WM_wstat_t *wst, short noli, short *cite,
short *posx ,short *posy, short *lis)


The parameters are as follows:

         "lad"  is a pointer to the loose item list in the working definition.
         "wst"  points to the status area.
         "noli" is tne number of loose items.
         "cite" is the number of the current loose item (0, 1 etc), or -1 if the
                pointer is not on a loose item.
         "posx" points to the absolute x-pointer position.
         "posy" points to the absolute y-pointer position.
         "lis"  points to an array li_set[] which contains 1 if the loose item
                has borders drawn.

If the pointer is outside the window (ie wst->xpos < 0), any set loose item is
unset. That is, any borders drawn are undrawn.

If the pointer is inside the window but not in any application window a check is
made to see if the pointer is on a loose item. If so, its borders are drawn and
any other borders undrawn.

If the pointer is in the window, the absolute position of the pointer is set in
the status area.

----------------------------------------------------------------------------
int do_fls (char * pars, char * prog)

Of the parameters "pars" points to the parameters for a QMenu Extension Thing
and "prog" is the address of the Extension Thing.

Provided both the addresses "pars" and "prog" are even, the code at byte 24 of
"prog" is obeyed and the resulting error code returned.

----------------------------------------------------------------------------
void do_sleep3 (chanid_t, WM_wwork_t *, short type, void * item, void * other,
               int *sizes)

The parameter "type" should be one of

                               Item              Other

         0 - for text          Text              NULL
         2 - for sprite        Sprite            NULL
         4 - for blob          Blob              Pattern for blob
         6 - for pattern       Pattern           Blob for pattern

to determine the nature of the contents of the button. The contents come from
"item" and "other" as indicated.

If "type" has a value outside the permitted range the button contents will be
the text NO NAME.

The parameter "sizes" is a pointer to an array of at least two members. The
second of these is taken to be the size required for the button's working
definition.

"do_sleep3" turns the current window into a button in the button frame if there
is one. If there is not a button frame the button is placed at the top left of
the screen.

The priority of the job is made 1 and the program waits until a hit, do or
CTRL/F2 is pressed. If there is a button frame, any of these will return the
original window. If there is no button frame, a hit will allow the button to be
moved and the others will return the original.

On return, the original priority is restored, and, if the original mode was 8
that is restored too.

----------------------------------------------------------------------------
int getptr (M_wwork_t *)

"getptr" returns the address pointed to by "ptr1" at the end of the window
definition.

----------------------------------------------------------------------------
int getsze (WM_wdefa_t *, int *ap, WM_wstat_t *, int *sizes, int *num)

The parameter "ap" is a pointer to prtab, the list of true pointers set up by
the preprocessor spr from the _z file.

The parameter "sizes" is a pointer to the array to contain the sizes for each
repeat of a window.

The parameter "num" is a pointer to the variable containing the number of main
windows.

More information about getsze appears in its source code.

----------------------------------------------------------------------------
short is_in (short xo, short yo, short xz, short yz, short px, short py)

The parameters are:

         xo/yo  = relative origin in window of "hit area".
         xz/yz  = size of "hit area".
         px/py  = relative position of pointer in window.

The return is 1 if px/py is in the area defined by the other parameters and 0
otherwise.

----------------------------------------------------------------------------
int slitem (WM_wwork_t *, short lno, short code)

Parameter "lno" is the loose item number to be reset.
Parameter "code" indicates how the resetting is to be done.

         code      meaning
            0      Available
            1      Selected
           -1      Unavailable

If "code" has a different value from any of these, or "lno" does not indicate a
valid loose item, an error is returned.

----------------------------------------------------------------------------
void wm__smnu(void)

This consists of one assembler instruction:

         jmp       8(a2)

It is used as the standard setup routine in a window definition for application
windows with a menu. It must not be used as a C68 function.



                             APPENDIX B
                        Sprites and Patterns

The sprites such as wm_sprite_size supplied in libqptr are defined for mode 4
only. A set of sprites and patterns defined for modes 4, 8 and 33 is supplied in
the library LIBCPTR.

All these sprites and patterns are declared as "externs" in the header file
WDEF_H so they can be used directly in any program using this system.


The sprites are:

----------------------------------------------------------------------------
struct WM_sprite   cpt_circ_spr
A dynamic circle

----------------------------------------------------------------------------
struct WM_sprite   cpt_curt_spr
A dynamic cursor (Mode 4 only)
The size is 6x10 and the origin is in the middle at (3, 5).

----------------------------------------------------------------------------
struct WM_sprite   cpt_dia_spr
A dynamic diamond shaped sprite

----------------------------------------------------------------------------
struct WM_sprite   cpt_down_spr
A downward pointing arrow

----------------------------------------------------------------------------
struct WM_sprite   cpt_hand_spr
A hand sprite

----------------------------------------------------------------------------
struct WM_sprite   cpt_left_spr
A leftward pointing arrow

----------------------------------------------------------------------------
struct WM_sprite   cpt_mve_spr
The move symbol

----------------------------------------------------------------------------
struct_WM_sprite   cpt_nul_spr
An invisible sprite

----------------------------------------------------------------------------
struct WM_sprite   cpt_right_spr
A right pointing arrow

----------------------------------------------------------------------------
struct WM_sprite   cpt_sze_spr
The size symbol

----------------------------------------------------------------------------
struct WM_sprite   cpt_up_spr
An up pointing arrow

----------------------------------------------------------------------------
struct WM_sprite   cpt_wake_spr
The wake symbol

----------------------------------------------------------------------------
struct WM_sprite   cpt_zzz_spr
The sleep symbol



The patterns are:


----------------------------------------------------------------------------
struct WM_sprite   cpt_bl_pat
A black pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_dg_pat
A dark green pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_dr_pat
A dark red pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_gr_pat
A green pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_gy_pat
A grey pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_lg_pat
A light green pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_lr_pat
A light red pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_mu_pat
A mustard pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_wh_pat
A white pattern

----------------------------------------------------------------------------
struct WM_sprite   cpt_re_pat
A red pattern





5th October 2008



George Gwilt
39 Oxgangs Road
Edinburgh EH10 7BE

TEL/FAX +44 (0)131 445 1266
e_mail:  gdgqler@gmail.com

