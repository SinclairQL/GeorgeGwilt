/* #include<stdlib.h> */
/* #include<stdio.h> */
#include<qdos.h>
#include<qptr.h>
/* #include"wind_eg.h" */
/* #include"wdef.h" */

/* slitem sets loose item number num (0, 1, . . ) to
 * the state indicated by ind
 *
 * ind	state
 *   0	available
 *   1	selected
 *  -1	unavailable
 */

int slitem(WM_wwork_t *wwd, short num, short ind)
{
unsigned char code;

 if (num < 0 || num > wwd->nlitm) return (-15);

 switch (ind) {
   case 0 :
     code = WSI_MKAV;
     break;
   case 1 :
     code = WSI_MKSL;
     break;
   case -1 :
     code = WSI_MKUN;
     break;
   default :
     return (-15);
     break;
  }

  wwd->wstat->litem[num] = code;
  return wm_ldraw(wwd, -1);

 }
