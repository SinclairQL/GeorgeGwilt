#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<qdos.h>
#include<qptr.h>
#include"wdef.h"

void Bset(short, WM_wstat_t *, WM_litm_t *, short *, short *);
void Bunset(WM_wstat_t *, short, short *, short *);

/* The parameters of Chk_IN are:
 *
 * lad	= -> loose item list
 * wst	= -> status area
 * noli	= number of loose items
 * cite	= -> current item (-1, 0, 1 ..) [(-1 = none)]
 * posx	= -> absolute x-pointer position
 * posy	= -> absolute y-pointer position
 * lis	= -> li_set[]
 *
 * If the pointer is outside the window (ie wst->xpos < 0), any set
 * loose item is unset. That is, any borders are undrawn.
 *
 * If the pointer is inside the window but not in any application window
 * a check is made to see if the pointer is in a loose item. If so, its
 * borders are drawn and any other drawn borders undrawn.
 */

void Chk_In(WM_litm_t *lad, WM_wstat_t *wst, short noli, short *cite,
short *posx,short *posy,short *lis)
 {
   WM_litm_t *lad1;
   short fd = 0;
   short px, py, ite, subw;
   short crite;
   lad1 = lad;
   px = wst->xpos;
   py = wst->ypos;

   if (px >= 0)
   {
    wst->ptpsx = *posx;
    wst->ptpsy = *posy;

    if ((subw = wst->swnr) == -1)
    {
     for (ite = 0; ite < noli; ++ite)
      {
       if (is_in(lad1->xorg, lad1->yorg, lad1->xsize, lad1->ysize, px, py))
	{ fd = 1;
	  break; }
       else lad1++;
      }
    }
   }
   if (fd)
   {
    if (*cite != ite)
     {
      Bunset(wst, noli, cite, lis);
      Bset(ite, wst, lad1, cite, lis);
     }
   }
    else
    {
      Bunset(wst, noli, cite, lis);
      *cite = -1;
      wst->citem = -1;
      }
}

/* The parameters of is_in are:
 *
 * xo/yo	= relative origin in window of "hit area"
 * xz/yz	= size of "hit area"
 * px/py	= realtive position of pointer in window
 *
 */

short is_in(short xo, short yo, short xz, short yz, short px, short py)
{
  if (xo > px) return (0);
  if (yo > py) return (0);
  if (xo + xz < px) return (0);
  if (yo + yz < py) return (0);
  return (1);
}

/* The parameters of Bunset are:
 *
 * ws	= -> status area
 * noli	= number of loose items
 * cite	= -> current item (-1, 0, 1 ..)
 * lis	= -> li_set[]
 */

void Bunset(WM_wstat_t *ws, short noli, short *cite, short *lis)
{
 short ite;

    int err;

    for (ite = 0; ite < noli ; ite++)
     {
      if (lis[ite]==1)
       {
         ws->citem = ite + (1<<15);

     wm_drbdr(ws->wwork);
    ws->citem &= 0x7F;
    lis[ite] = 0;
    break;
    }
}
}

/* The parameters of Bset are:
 *
 * x	= item number (1, 2, ..)
 * ws	= -> status area
 * li	= -> loose item list
 * cite	= -> current item (-1, 0, 1 ..)
 * lis	= -> li_set[]
 */

void Bset(short x, WM_wstat_t *ws, WM_litm_t *li, short *cite, short *lis)
{
 WM_wwork_t *wwd;
 int err;

 wwd = ws->wwork;
 *cite = x;
 if (ws->litem[x] != 0x10)
  {
   ws->citem = x;
   ws->cibrw = wwd->curw;
   ws->cipap = wwd->curc;
   ws->cihxs = li->xsize;
   ws->cihys = li->ysize;
   ws->cihxo = li->xorg + wwd->xorg;
   ws->cihyo = li->yorg + wwd->yorg;

   if (err = wm_drbdr(ws->wwork)) exit (err);

   ws->cipap = wwd->papr;

   lis[x] = 1;
   }
}
