#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<qdos.h>
#include<qptr.h>
#include"wdef.h"

int dswake (WM_wwork_t *,WM_litm_t *,WM_wstat_t *,short,short,short,short);
static struct WM_action aswake = {JSR, wm_actli, dswake};
int dswake1 (WM_wwork_t *,WM_litm_t *,WM_wstat_t *,short,short,short,short);
static struct WM_action aswake1 = {JSR, wm_actli, dswake1};
int slitem(WM_wwork_t *, short, short);



void  do_sleep3(chanid_t chid,WM_wwork_t *wwk,short typ,void *title,void *other,int *tizes)
{


#define ti_max 60
   static QD_TEXT(ti_max) _title={7,"NO_NAME"};

   int opr, lpn, ypn;
   short mode1, mode2, type;
   short posx, posy, szx, szy, pxorg, pyorg;
   int nobut = 0;
   WM_wdef2_t *wd;
   WM_wstat_t *ws;
   static  WM_wstat_t ws1;
   WM_wwork_t *swk;
   WM_wwork_t **ww,**sw;
   WM_sprite_t *ttl;
   wd = (WM_wdef2_t *)wwk->wscale;  /* This points to the window definiton */
   ws = wwk->wstat;
   szx = wwk->xsize;
   szy = wwk->ysize;
   pxorg =  wd->wdefa.xorg;
   pyorg =  wd->wdefa.yorg;
   posx = wwk->xorg + pxorg;
   posy = wwk->yorg + pyorg;
   ww = &wwk;

   mode1 = -1;
   type = -1;


   if ((opr = mt_prior(-1,1))<0) exit (opr);

   mt_dmode(&mode1, &type);

   if ((mode2 = mode1) == 8)
    { mode1 = 4;
     type = -1;
     mt_dmode(&mode1, &type); }


    switch (typ) {
     case 2:
     case 4:
      ttl = (WM_sprite_t *)title;
      break;
     case 6:
      ttl = (WM_sprite_t *)other;
      break;
     case 0:
      QD_STXT (_title, title, ti_max);
     default:
      typ = 0;
      lpn = 4*((_title.len * 6 + 3) / 4);
      ypn = 12;
      break;
      }

     if (typ != 0) {
      lpn = 4*((ttl->xsize + 3)/4);
      ypn = ttl->ysize+2;
      }

   wm_unset(wwk);

     if (!(swk = malloc(tizes[1]))) exit (-3);
     sw = &swk;

    wd->wdefa.xorg = 8;
    wd->wdefa.yorg = 7;


   if (wm_setup(chid, lpn + 4, ypn, wd, &ws1, sw, 0)) exit (-3);

   swk->flag = 0;
   swk->borw = 1;
   swk->borc = 4;
   swk->papr = 7;
   swk->sprite = NULL;
   swk->plitm->xsize = lpn;
   swk->plitm->ysize = ypn-2;
   swk->plitm->xorg = 2;
   swk->plitm->yorg = 1;
   swk->plitm->type = typ;

   switch (typ) {
     case 0:
      swk->plitm->pobj = &_title;
      break;
     case 4:
      swk->apatt = other;
      swk->spatt = other;
      swk->plitm->pobj = title;
      break;
     case 6:
      swk->ablob = other;
      swk->sblob = other;
     case 2:
      swk->plitm->pobj = title;
      break;
      }


   if (bt_prpos (swk))
    { if (wm_prpos (swk,0,0)) exit (-4);
      nobut = 1; }
   if (nobut) swk->plitm->pact = &aswake1;

   else swk->plitm->pact = &aswake;

   if (wm_wdraw (swk)) exit (-4);

   while (!wm_rptr(swk))
    if (ws1.evnt & PT_WAKE) break;

   wm_unset(swk);
   free(swk);

   if (!nobut)  bt_free();

   if (mode2 == 8)
    {
     mode1=8;
     type=-1;
     mt_dmode(&mode1, &type); }

    wd->wdefa.xorg = pxorg;
    wd->wdefa.yorg = pyorg;

   if (wm_setup(chid, szx, szy, wd, ws, ww, 0)) exit (-3);

   if (wm_prpos(wwk, posx, posy)) exit (-4);
   if (wm_wdraw (wwk)) exit (-4);

   if ((opr = mt_prior(-1,opr)) <0) exit (opr);


 }


int dswake(WM_wwork_t *wwk, WM_litm_t *li,
		WM_wstat_t *wst, short xpos, short ypos,
		short key, short event)
{

   slitem (wwk,0,0);
   return PT__WAKE;

}

int dswake1(WM_wwork_t *wwk, WM_litm_t *li,
		WM_wstat_t *wst, short xpos, short ypos,
		short key, short event)
{
	short dx,dy;
   if (key == 2)
   {  slitem(wwk,0,0);
   return PT__WAKE; }
   else
   {

	wst->evnt  |= PT_WMOVE;
	wm_chwin (wwk,&dx,&dy); }

	return slitem(wwk,0,0);



}

/***********************************************************************
 * The routine do_sleep sends a program into a button until it is
 * returned by an appropriate key- or mouse-press.
 *
 * This particular version is based on the form of window produced
 * by an application of TurboPTR's setf_task which automatically
 * sets two repeated sections for the main window. The first section
 * is for the normal main window. The second section is set up with
 * a variable x-size with smallest value zero and with a fixed
 * y-size of 10. This is to allow the setting up of a button of the
 * correct dimensions. This button window has one loose item of
 * variable x-size (minimum 20) and fixed y-size of 12. The intention
 * is for the name of the program to be used as the loose item.
 *
 * The stages in buttonising and later de-buttonising are:
 *
 *	1. Setting the priority to 1.
 *	2. "Unsetting" the main window.
 *	3. Allocating space for the button's size.
 *	4. Using wm_setup to get the new working definition.
 *	5. Setting the true size of button.
 *	6. Setting the action routine to the loose item.
 *	7. Pulling down and drawing the button.
 *	8. Reading the pointer until . . .
 *	9. . . . a wake event appears (see 6.)
 *       10. "Unsetting" the button.
 *       11. Using wm_setup to set the original window.
 *       12. Pulling down and redrawing the window.
 *       13. Resetting the original priority.
 *
 * The parameters needed for do_sleep are:
 *
 *	1. Channel ID for the main window.
 *	2. Pointer to the main window's working definition.
 *	3. The type of object.
 *		0 = text
 *		2 = sprite
 *		4 = blob
 *		6 = pattern
 *	4. Pointer to the object to be used in the button.
 *	5. Pointer to second object or NULL depending on type
 *		0 -> NULL
 *		2 -> NULL
 *		4 -> pattern
 *		6 -> blob
 *	6. Pointer to an array of integers carrying the sizes
 *	   needed for the main window's and the button's
 *	   working definitions.
 *
 * The loose item's action routine has to force an exit from wm_rptr
 * so that the main window can be restored. This is achieved by a
 * non-zero return from the action routine. The routine (dswake) has
 * only two instructions. The first resets the loose item to "available".
 * The second returns the "event number" for wake. This forces a return
 * from wm_rptr with the appropriate event set in the event vector in
 * the status area.
 *
 *  Comments on the 13 stages:
 *
 * 1. Priority
 *    The old priority is set in "opr" and the new priority is set to
 *    1 by the same application of mt_prior. Setting the priority to 1
 *    ensures that if there is a button frame our button will be a full
 *    member.
 *
 *    The button must not be in mode 8, so we find the mode, put it in
 *    mode2 and set the mode to 4 if it was 8.
 *
 * 2. "Unsetting" the main window.
 *    We unset using "wm_unset".
 *
 * 3. Allocating space for the button's size.
 *    The routine "getsze" sets the sizes needed for each repeated
 *    section of a window in an array such as wd_sizes. This is the
 *    array which should be the last parameter of "do_sleep". The
 *    first element contains the main window's size and the second the
 *    size of the button's working definition.
 *
 * 4. The parameters for "wm_setup" are:
 *	a) chid - from the first parameter of "do_sleep"
 *	b) x-size (lpn)
 *	   i) if string
 *	      - length in bytes of "title" rounded up to a multiple of 4
 *	  ii) if blob or sprite
 *	      - width of blob or sprite rounded up to a multiple of 4
 *	 iii) if pattern
 *	      - width of associated blob rounded up to a multiple of 4
 *	c) y_size (ypn)
 *	   i) if string
 *	     - 12
 *	  ii) if blob or sprite
 *	     - height of blob or sprite  + 2
 *	 iii) if pattern
 *	     - height of associated blob + 2
 *	d) window definition - found from wwk
 *	e) status area - a new area for the button (ws1)
 *	f) new working definition - ww
 *	g) alloc - zero because it has been allocated
 *
 * 5. Setting the true size of button.
 *    The working definition sets up the button window with its correct
 *    size.
 *    We now have to set the window attributes . .
 *
 *	a) flag (=shadow) - 0
 *	b) border width - 1
 *	c) border colour - black
 *	d) paper colour - white
 *	e) available/selected pattern for type 4
 *	   available/selected blob	for type 6
 *
 *   . . the sprite . .
 *
 *	e) default (NULL)
 *
 *   . . and the loose item
 *
 *	f) xsize - lpn
 *	g) ysize - ypn - 2
 *	h) xorg - 2
 *	i) yorg - 1
 *	j) the object itself - title/sprite/blob/pattern
 * 6.	k) the action routine - "aswake"
 *
 * 7. Pulling down and drawing the button.
 *    If there is a button frame, bt_prpos will find a place and set the
 *    button in it. The variable nobut remains zero.
 *    If not, we use wm_prpos to set the button to position 0,0 at the
 *    top left of the screen. The variable nobut is set to 1.
 *    Once that is done wm_draw draws the contents.
 *
 * 8. Reading the pointer until . .
 *    wm_rptr reads the pointer until an exit occurs. If on exit there
 *    is a wake event set in the event vector, the "while" loop is broken
 *
 * 9. . . a wake event appears
 *    If SPACE, ENTER, CTRL/F2 or a mouse click occurs, the action
 *    routine "dswake" is invoked to set a wake event and to cause a
 *    return from wm_rptr.
 *
 *10. "Unsetting" the button.
 *    "wm_unset" and "free" are used to throw away the button's working
 *    definition.
 *    If nobut = 0, the button is removed from the frame.
 *
 *    Since the mode might have changed we reset it to 8 if that was the
 *    original mode.
 *
 *11. The old window definition is restored by wm_setup. This time the
 *    original size of the window which was stored in szx/szy is used.
 *
 *12. The original window is again pulled down using wm_prpos with
 *    the original position which has been stored in posx/posy.
 *    This position is the absolute position of the top left of the
 *    window (found from the original working definition) to which the
 *    pointer origin from the window definition is added.
 *
 *    The contents are redrawn using wm_wdraw.
 *
 *13. Resetting the original priority.
 *    "mt_prior" is used with the parameter "opr" to reset the priority.
 ***********************************************************************/
