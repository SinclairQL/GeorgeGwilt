/* spr_c
 *
 * 26th March 2002 - v1.2
 * Altered to take only one parameter. The list is now automatically "prtab"
 *
 * 3rd February 2000
 *
 * A program to set numbers in place of %%< name >
 *
 * Call it by:
 *  EX spr;'<name of pointer table> <name of program>'
 *
 * If the pointer table is called 'prtab' and the program 'test'
 * then test_z should contain the targets of the word pointers
 * enclosed in either
 *
 *	%%<	>	(Where the target itself may need processing)
 *
 * or	%%<<	>	(Where no further processing is wanted).
 *
 * Then
 *
 *	ex spr;'prtab test'
 * or	ex spr;'prtab ram1_test'
 * or	ex spr;'prtab test_z'
 * or	ex spr;'prtab ram1_test_z'
 *
 * will process "ram1_test_z" onto "ram1_test_c", assuming that
 * DATAD$ is RAM1_.
 *
 * The program works by copying from _z to _c until %%< is reached outside a
 * comment. The ensuing name is added to a list and %%<...> replaced by the
 * number of its position in the list. A null name causes the "prtab" list
 * itself to be produced. Thereafter the remainder of the file is copied
 * without cahnge.
 */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<qdos.h>

#define LIM 32 /* maximum word length */

void (*_consetup)() = NULL;
char *_endmsg = NULL;
char _prog_name[] = "spr v1.3";

static struct tlist {
char *word;
struct tlist *next;};
char *fname,c;
struct tlist strt = {NULL,NULL};

char iname[32],oname[32];

void erout(char, char *);
void do_end(FILE *, struct tlist *);
int do_word(FILE *, FILE *, struct tlist *);
void gop_com(FILE *, FILE *);
char set_word(struct tlist *,char *);
char *gwd(FILE *);
char *strsve(char *);


int main(int argc, char *argv[])
{

	int fi = 0;	/* The process continues until fi = 1 */
	FILE *infl,*outfl;


	if (argc != 2) erout(4,NULL); /* There must be two arguments */

	fname = argv[1];	/* The file to be processed */

	/* A trailing "_z" is stripped off */

	if ((fname[strlen(fname)-2] == '_') && (fname[strlen(fname)-1] == 'z'))
		fname[strlen(fname)-2] = '\0';

	strcpy(iname,fname);
	strcpy(oname,fname);

	strcat(iname,"_z"); /* The input name ends "_z"  */
	strcat(oname,"_c"); /* The output name ends "_c" */

	if (!(infl = fopen(iname,"r"))) erout(1,iname);
	if (!(outfl = fopen(oname,"w"))) erout(1,oname);

 /* Until fi = 1 we search for %, EOF or / */

	while (!fi) {

		while ((c = getc(infl)) != '%' && c != EOF && c != '/')
			putc(c,outfl);

		if (c == EOF) {

		   if (!(&strt)->word) return (0);

 /* If there have been 'words' EOF is a mistake */

		   else  erout(2,NULL);
		   }

 /* If / is encountered followed by * it is a "comment" to be copied
  * by "gop_com" until the end marker (* followed by /)
  */
		else if (c == '/') {
		   putc(c,outfl);
		   c=getc(infl);
		   putc(c,outfl);
		   if (c == '*') gop_com(infl,outfl);
		   }

		else { /* c must be '%' */
		   if ((c = getc(infl)) !='%') {
		      putc('%',outfl);
		      putc(c,outfl);
		      }
		   else {
		      if ((c = getc(infl)) != '<') {
		         putc('%',outfl);
		         putc('%',outfl);
		         putc(c,outfl);
		         }

 /* "%%<" has been found. If a new word follows it is entered in the list.
  * If the word is null, the table is output by "do_end" and "fi" set to 1
  */

		      else
		         if (do_word(infl,outfl,&strt)) {
			do_end(outfl,&strt);
			fi=1;

 /* The remainder of _z is copied to _c
  */
			while ((c = getc(infl)) != EOF)
			  putc(c,outfl);
			if (!(&strt)->word) erout (6,NULL);
			}
		      }
		   }
	}
	return(0);
}

int do_word(FILE *in ,FILE *out ,struct tlist *p)
{

 /* 1. If the word read by "gwd" is not null, its number in the list
  *    is found by "set_word" and output preceded by "-" if there are
  *    two "<"s. The return is 1.
  * 2. If the word is null, there is no ouput and 0 is returned.
  */
	char *w, c;
	int neg;

	if ((c = getc(in)) == '<') neg=1; /* negative */
	else { ungetc(c,in);
	       neg = 0;
	       }

/*	  w=gwd(in);  get word up to ">" */

	if (!strlen(w = gwd(in))) return (1); /* %%<> or %%<<> found */

	else {

	if (neg) putc('-',out); /* negative */
	fprintf(out,"%d",set_word(p,w));

	return (0);
	}
}

char set_word(struct tlist *p,char *w)
{

 /* If "w" is not in the list "p", it is added. In either case its position
  * in the list is returned.
  */
	struct tlist *ps;
	int num = 0;

	if (p->word == NULL) {
	  p->word = strsve(w);
	  p->next = NULL;
	  return (1);
	  }
         else {
	  do {
	     ps = p;
	     num++;
	     if (!strcmp(w,p->word)) return (num);
	     }
	  while (!((p = p->next) == NULL));

	  if (!(p = malloc(sizeof(struct tlist)))) erout (3,NULL);
	  ps->next = p;
	  p->word = strsve(w);
	  p->next = NULL;
	  return (++num);
	  }
}

char * gwd(FILE *in)
{

 /* This returns a pointer to the word found before ">".
  * If there is no ">" or the word is longer than LIM, an error exit occurs
  */
	char c, *w;
	int lim, i = 0;

	w = malloc(LIM+1);

	for(lim = LIM; (c = getc(in)) != EOF && c != '>' && lim; lim--)
	  w[i++] = c;
	if (c == EOF) erout (2,NULL);
	if (!lim) erout (5,NULL);
	w[i] = '\0';

	return (w);
}

char * strsve(char * s)
{

 /* This returns the pointer to where the string "s" is saved
  */
	char *p;

	if ((p = malloc(strlen(s)+1)) != NULL)
	  strcpy(p,s);

         return (p);
}

void erout(char n , char * w)
{
 /* This prints one of a set of error messages before quitting
  */

  char *mess ;
  chanid_t chid;
  QLRECT_t temp =
  {240,32,20,10};

  chid = fgetchid(stderr);
  setbuf(stderr, NULL);
  sd_wdef(chid,-1,255,1,&temp);
  sd_setpa(chid,-1,0);
  sd_setst(chid,-1,0);
  sd_setin(chid,-1,4);
  sd_clear(chid,-1);

  mess = "          ERROR MESSAGE";
  fprintf(stderr,"%-34s\n\n",mess);

  sd_setin(chid,-1,7);

	switch (n) {
	  case 1 :
		mess = strcat("Can't open ",w);
		break;
	  case 2 :
		mess = "No ending '>'";
		break;
	  case 3 :
		mess = "Out of space";
		break;
	  case 4 :
		mess = "Wrong number of arguments";
		break;
	  case 5 :
		mess = "Word too long";
		break;
	  case 6 :
		mess = "WARNING: Ending '>' with no words";
		break;
	  case 7 :
		mess = "No \\\052 to end comment";
	  }

	fprintf(stderr,"%-34s\n" , mess);
	mt_susjb(-1,300,NULL);
	exit(0);
}

void do_end(FILE *of, struct tlist *p)
{
 char *s = "prtab";
 /* This outputs the non-empty list "p" to the table called prtab.
  */
       if (p->word) {

	fprintf(of,"static void *%s[] = {\n\11",s);

	do {
	  fprintf(of,"%s,\n\11", p->word);
	  p = p->next;
	  }
	while (p != NULL);

	fprintf(of,"};");
       }
}

void gop_com(FILE *in, FILE *out)
{

 /* This copies from _z to _c all characters up to and including the final
  * "*" followed by "/", unless EOF occurs first in which case an error
  * exit is taken.
  */
	int go=1;

	while ((c = getc(in)) != EOF && go) {
	  putc(c,out);
	  if (c == '*') {
	    c=getc(in);
	    putc(c,out);
	    if (c == '/') go = 0;
	    }
	  }
	if (c == EOF) erout (7,NULL);
	else ungetc(c,in);
}
